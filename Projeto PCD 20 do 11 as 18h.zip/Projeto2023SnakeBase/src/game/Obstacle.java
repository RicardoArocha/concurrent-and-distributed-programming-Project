package game;

import environment.Board;
import environment.BoardPosition;

public class Obstacle extends GameElement {
	
	
	private static final int NUM_MOVES=3;
	public static final int OBSTACLE_MOVE_INTERVAL = 400; //400 e private default
	private int remainingMoves=NUM_MOVES;
	private Board board;
	private BoardPosition position;
	
	public Obstacle(Board board) {
		super();
		this.board = board;
		position = board.addGameElement(this);		
	}
	
	public int getRemainingMoves() {
		return remainingMoves;
	}
	
	public boolean decrementRemainingMoves() {
		
		if(remainingMoves > 0) {
			remainingMoves --;
			return true;
		}
		
		return false;
	}
	
	
//	public boolean move() throws InterruptedException { Versao de 19/11/23
//		
//		if(decrementRemainingMoves() == false) return false; //caso nao se possa mover mais, devolve falso
//		
//		BoardPosition oldPosition = position;		
//		position = board.addGameElement(this);
//		board.getCell(oldPosition).removeObstacle();
//		board.setChanged();
//		
//		return true;
//		
//	}
	
	public boolean move() throws InterruptedException { //Versao de 20/11/23
			
		if(decrementRemainingMoves() == false) return false; //caso nao se possa mover mais, devolve falso
		
		BoardPosition oldPosition = position;		
		position = board.addGameElement(this);
		board.getCell(oldPosition).removeObstacle();
		board.setChanged();
		
		return getRemainingMoves() > 0; //caso tenha sido o seu ultimo movimento, devolve falso para ser removido da lista de objetos
			
	}
	
	

}
