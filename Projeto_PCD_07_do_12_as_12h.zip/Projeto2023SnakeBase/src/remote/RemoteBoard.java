package remote;

import java.awt.event.KeyEvent;
import java.util.Iterator;
import java.util.LinkedList;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;
import environment.LocalBoard;
import game.Obstacle;
import game.Snake;
import gui.SnakeGui;

/** Remote representation of the game, no local threads involved.
 * Game state will be changed when updated info is received from Srver.
 * Only for part II of the project.
 * @author luismota
 *
 */

public class RemoteBoard extends Board{
	
	private Client client;
	SnakeGui game;

	public RemoteBoard(Client client) {
		super();
		this.client = client;
		
		startSnakeGUI();
	}
	
	private void startSnakeGUI() {
		game = new SnakeGui(this,800,200); //Posicao no tabuleiro em H,V
		game.init();
	}
	
	@Override
	public void handleKeyPress(int keyCode) {
		//TODO
		String message = null;
		
		switch (keyCode) {
        case KeyEvent.VK_UP:
            message = "UP";
            break;
        case KeyEvent.VK_DOWN:
            message = "DOWN";
            break;
        case KeyEvent.VK_LEFT:
            message = "LEFT";
            break;
        case KeyEvent.VK_RIGHT:
            message = "RIGHT";
            break;
    }		
		if(message != null) client.sendMessageToServer(message);
	}
	

	@Override
	public void handleKeyRelease() { //nao vejo necessidade de implementar
		// TODO
	}

	@Override
	public void init() { // nao vejo necessidade de implementar
	}

	public void updateRemoteBoard(LocalBoard localBoard) { //Atualiza a remote board com todas as novas celulas
		
		if(localBoard.hasGameEnded()) client.shutdown();
		
		
		
		cells = new Cell[NUM_COLUMNS][NUM_ROWS];
		
		for (int x = 0; x < NUM_COLUMNS; x++) { //Atualiza as Cells
			for (int y = 0; y < NUM_ROWS; y++) {
//					cells[x][y].request(localBoard.getCell(x,y).getOcuppyingSnake());
//					cells[x][y].setGameElement(localBoard.getCell(x,y).getGameElement());	
				//cells[x][y] = localBoard.getCell(new BoardPosition(x,y));
//				Cell cell = new Cell(new BoardPosition(x,y));				
//				cell.setGameElement(localBoard.getCell(new BoardPosition(x,y)).getGameElement());
//				try {
//					cell.request(localBoard.getCell(new BoardPosition(x,y)).getOcuppyingSnake());
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//					System.out.println("[unable to get and set OcuppyingSnake]");
//				}
//				cells[x][y] = new Cell(new BoardPosition(x, y));
//				cells[x][y].setGameElement(localBoard.getCell(new BoardPosition(x,y)).getGameElement());
//				try {
//					cells[x][y].request(localBoard.getCell(new BoardPosition(x,y)).getOcuppyingSnake());
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//					System.out.println("[unable to get and set OcuppyingSnake]");
//				}
				
				cells[x][y] = localBoard.getCell(new BoardPosition(x, y));
			}
		} 
		
		snakes.clear();
		snakes.addAll(localBoard.getSnakes());
		
		obstacles.clear();
		obstacles.addAll(localBoard.getObstacles());
		
		setChanged();
		
		System.out.println("[RemoteBoard tried updating]\n");
	}
	
	

}
