package game;

import java.io.Serializable;

import environment.Board;

public class Goal extends GameElement implements Serializable  {
	private int value=1;
	private Board board;
	public static final int MAX_VALUE=9; //Valor original = 10
	
	public Goal( Board board2) {
		this.board = board2;
	}
	
	public int getValue() {
		return value;
	}
	public void incrementValue() { //incrementa o valor do Goal
		//TODO
		if (value < MAX_VALUE) value++;
	}

	public int captureGoal() throws InterruptedException { //Devolve o valor de Goal e cria um novo Goal incrementado
		//TODO
		int oldValue = getValue(); //Guarda o valor a ser devolvido
		
		if(oldValue < MAX_VALUE) { //Caso nao seja o Goal final, cria um novo com o valor incrementado
		incrementValue();
		board.addGameElement(this); //Adiciona o Goal a uma posicao livre aleatoria
		}		
		
		return oldValue;
	}
}
