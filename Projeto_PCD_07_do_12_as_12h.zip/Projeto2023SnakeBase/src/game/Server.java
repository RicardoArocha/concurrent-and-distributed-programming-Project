package game;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

import environment.Cell;
import environment.LocalBoard;
import gui.SnakeGui;

/*
 * Processar informacao recebida e alterar a localBoard
 * 
 * Enviar o novo estado da localBoard. Para enviar este novo estado, acho que posso simplesmente enviar a lista de cells, testar esta ideia
 * 
 * 
 * */

public class Server {
	private ServerSocket server;
	private LocalBoard localBoard;
	
	public Server(LocalBoard localBoard) {
		this.localBoard = localBoard;
	}
	
	public void runServer() {  //Igual ao feito em aula, nao e necessario alterar
		try {
			// 1. Create socket
			server = new ServerSocket(12345, 1);
			while(true) {
				// 2. Wait for a new connection
				waitForConnection();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}

	private void waitForConnection() throws IOException { //Igual ao feito em aula, nao e necessario alterar
		System.out.println("Waiting for a new connection...");
		Socket connection = server.accept(); // WAIT!!
		
		// Create a connection manager (ConnectionHandler)
		ConnectionHandler handler = new ConnectionHandler(connection);
		handler.start();
		System.out.println("[new connection] " + connection.getInetAddress().getHostName());
	}

	private class ConnectionHandler extends Thread { //--------------------------------------------ConnectionHandler para cada Client
		private Socket connection;
		private Scanner in;
		//private PrintWriter out; //Vou enviar objetos, nao strings
		private ObjectOutputStream objectOutput;
		private int snakeId;
		private Snake snake;
		
		
		public ConnectionHandler(Socket connection) {
			this.connection = connection;
			
			if(localBoard.getSnakes().isEmpty()) snakeId = 1;
			else snakeId = localBoard.getSnakes().getLast().getIdentification() + 1; //Pode vir a causar problemas, como cobras com o mesmo ID. Fazer Id random caso necessario
			
			snake = new Snake(snakeId,localBoard);
			localBoard.addSnake(snake);
			snake.doInitialPositioning();
		}

		@Override
		public void run() {
			try {
				getStreams();
				//processConnection();
				
				 // Create and start the thread for sending board updates
	            Thread sendUpdatesThread = new Thread(this::sendBoardUpdates);
	            sendUpdatesThread.start();
	            
	            // Process incoming moves in this thread
	            receiveMoves();

				
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				closeConnection();
			}
		}
		
		
		private void getStreams() throws IOException { //Manter
			// Writer
			//out = new PrintWriter(connection.getOutputStream(), true);
			objectOutput = new ObjectOutputStream(connection.getOutputStream());
			
			// Reader
			in = new Scanner(connection.getInputStream());
			System.out.println("[ready to proceed connection]");
		}
		
//		private void processConnection() {
//			
////			Thread sendUpdatesThread = new Thread(this::sendBoardUpdates);
////            sendUpdatesThread.start();//Inicia a Thread que envia atualizacoes periodicas do estado da Board            
//			
//			sendBoardUpdates();
//            
//            receiveMoves(); //Recebe msg em String do cliente e move a cobra respetiva
//		}

		private void receiveMoves() { //Deve receber em string os movimentos do jogador e fazer a cobra mover-se de acordo
			String msg;
			do {
				// Read message
				msg = in.nextLine(); // WAIT!! //Espera caso nada tenha sido ainda enviado
				
				try { //Pede a cobra para se mover nessa direcao
					snake.move(msg);
				} catch (InterruptedException e) {
					e.printStackTrace();
				} 
				
				System.out.println("[received] " + msg + " for Snake #" + snakeId);
				// Write echo
				//out.println("[server echo] " + msg);			
				
			}while(!localBoard.hasGameEnded());
			
		}
		
		private void sendBoardUpdates() { //Deve enviar atualizacoes periodicas do estado do jogo //Nesta primeira versao, envia todas as cells da localBoard
			do { 
				
				try {
					
					objectOutput.writeObject(localBoard);
					System.out.println("[Server - Sent localBoard to Client]");
					
					Thread.sleep(localBoard.REMOTE_REFRESH_INTERVAL);
//					Thread.sleep(5000);
					
				} catch (InterruptedException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				
			}while(!localBoard.hasGameEnded());
		}
		


		private void closeConnection() { //Igual ao feito em aula, ano e necessario alterar
			try {
				if(in != null)
					in.close();
//				if(out != null)
//					out.close();
				if (objectOutput != null) {
			        objectOutput.close();
			    }
				if(connection != null)
					connection.close();
			} catch (IOException e) {
				e.printStackTrace();
			}		
		} 
		
		
		
		
		
		
	}	
	
	
//	public static void main(String[] args) { // O servidor e iniciado na classe main, assim sendo nao faz sentido ter main aqui
//		Server serverApp = new Server();
//		serverApp.runServer();
//	}


}
