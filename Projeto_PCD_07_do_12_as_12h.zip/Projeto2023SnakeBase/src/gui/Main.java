package gui;

import environment.LocalBoard;

import game.Server;

//Imports for debugging, delete afterwards
import remote.RemoteBoard;

public class Main {
	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) {
		LocalBoard board=new LocalBoard();
		SnakeGui game = new SnakeGui(board,200,200); //Posicao no tabuleiro em H,V. Valores originais 600, 200
		game.init();
		// Launch server 
		Server serverApp = new Server(board);
		serverApp.runServer();	
	} 
	
//	public static void main(String[] args) { //Main para debugging
//	LocalBoard board=new LocalBoard();
//	SnakeGui game = new SnakeGui(board,200,200); //Posicao no tabuleiro em H,V. Valores originais 600, 200
//	game.init();
//	//TODO Testar o RemoteBoard
//	
//	RemoteBoard rm = new RemoteBoard(null);
//	rm.updateRemoteBoard(board.getCells());
//}
	
}

/*
 * ---------------------COISAS A IMPLEMENTAR
 * 
 * Server, fazer todo o codigo da classe e inicia lo no main
 * 
 * Client, fazer todo o codigo da classe
 * 
 * Remote Board, fazer todo o codigo da classe, este e o responsavel por aceitar as keypresses e atualizar a board
 * 
 * Movimento do jogador, ele não deve ficar parado em nenhuma casa, ou será que deve?
 * 
 * Deve haver alguma restrição temporal no movimento do jogador, ou quanto mais rápido ele jogar mais rápido anda
 *  
 * Protecao no addGameElement
 * 
 * Saber como posso ler as teclas direcionais, ou se é preferivel fazer com AWSD
 * 
 * Apenas o server pode alterar a posição das snakes diretamente. Ou seja, o server talvez deva extender o local board. Isto só será necessário se não der para alterar a local board externamente.
 * 
 * ---------------------O QUE ESTA A SER IMPLEMENTADO ATUALMENTE
 * 
 * Server---
 * Mover cobras e enviar o novo estado da board
 * 
 * 
 * --------------------COISAS A TER ATENCAO E Q&A
 * 
 * como enviar as keypresses dos arrowKeys na consola? nao da, tem que ser feito atraves da remoteBoard
 * 
 * A classe AutomaticSnake tem que ser desativada? Sim
 * 
 * Visto que o jogo é local, não faz sentido existir um limite de tempo? Nao faz
 * 
 * A cobra deve sim bloquear, mas este bloqueio pode ser alterado caso o jogador tente jogar novamente. Ou seja, sempre que o jogador faz um movimento, este deve resetar o movimento anterior. ?? Confirmar com professora
 * 
 * como e que o board consegue detetar as setas? Isto ja esta implementado no BoardComponent
 * 
 * --------------------PROBLEMAS ENCONTRADOS E QUE ESTAO POR RESOLVER
 * 
 * como e que o board comunica ao cliente que este deve enviar uma mensagem para o servidor a pedir um movimento
 * 
 * 
 * talvez o servidor nao consiga aceder ao novos estados da localBoard
 * 
 *---------------------FASES DE IMPLEMENTACAO
 *
 *comecar pelo servidor, este devera receber as mensagens enviadas pelos clientes e alterar a local board
 *devera enviar o novo estado da board para os clientes cada vez que for chamado um updateGUI na local board. Ou seja, sempre que algo se mover, tanto as cobras, quanto os objetos ou o goal.
 * 
 * a seguir implementar o remote board, este sera responsavel por mostrar o estado atual do jogo, assim como fazer a leitura das keypresses dos jogadores
 * 
 * cliente, este sera responsavel pela comunicacao com o servidor, enviado as keypresses do remoteBoard e atualizando o remoteBoard
 */










