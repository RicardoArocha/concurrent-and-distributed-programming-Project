package environment;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import game.AutomaticSnake;
import game.Goal;
import game.Obstacle;
import game.ObstacleMover;
import game.Snake;

/** Class representing the state of a game running locally
 * 
 * @author luismota
 *
 */
public class LocalBoard extends Board {
	
	private static final int NUM_SNAKES = 2; //number of automatic snakes
	private static final int NUM_OBSTACLES = 25; // Default value = 25
	//private static final int NUM_SIMULTANEOUS_MOVING_OBSTACLES = 3;

	

	public LocalBoard()  {
		
		for (int i = 0; i < NUM_SNAKES; i++) {
			AutomaticSnake snake = new AutomaticSnake(i, this);
			snakes.add(snake);
		}

		addObstacles( NUM_OBSTACLES); 
		
		Goal goal=addGoal();
//		System.err.println("All elements placed");
	}

//	public void init() {
//		for(Snake s:snakes)
//			s.start();
//		// TODO: launch other threads
//		ObstacleMover deleteAfterwards = new ObstacleMover(null,this); //testes, apagar mais tarde
//		deleteAfterwards.run();
//		
//		setChanged();
//	}
	
	public void init() {
		for(Snake s:snakes)
			s.start();
		// TODO: launch other threads
		//ExecutorService obstacleExe = Executors.newFixedThreadPool(NUM_SIMULTANEOUS_MOVING_OBSTACLES); //Cria a ThreadPool
		for (Obstacle obstacle : getObstacles()){
			obstacleExe.submit(new ObstacleMover(obstacle, this));
		}
		
		setChanged();
	}	

	@Override
	public void handleKeyPress(int keyCode) {
		// do nothing... No keys relevant in local game
	}

	@Override
	public void handleKeyRelease() {
		// do nothing... No keys relevant in local game
	}





}
