package game;

import environment.Board;
import environment.BoardPosition;
import environment.LocalBoard;

public class Obstacle extends GameElement {
	
	
	public static final int NUM_MOVES=3;
	public static final int OBSTACLE_MOVE_INTERVAL = 400;
	public int remainingMoves=NUM_MOVES;
	private Board board;
	private BoardPosition position;
	
	public Obstacle(Board board) {
		super();
		this.board = board;
		this.position = board.getRandomPosition(); // Inicializa com uma posi��o aleat�ria.
    }
	
    public void setPosition(BoardPosition position) {
        this.position = position;
    }

    public BoardPosition getPosition() {
        return position;
    }
	
	public int getRemainingMoves() {
		return remainingMoves;
	}
}
