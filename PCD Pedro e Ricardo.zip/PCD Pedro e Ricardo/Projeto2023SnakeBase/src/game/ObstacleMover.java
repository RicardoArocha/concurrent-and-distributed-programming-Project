package game;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;
import java.util.List;
import java.util.Random;

public class ObstacleMover implements Runnable {
    private Obstacle obstacle;
    private Board board;
    private Random random = new Random();

    public ObstacleMover(Obstacle obstacle, Board board) {
        this.obstacle = obstacle;
        this.board = board;
    }

    @Override
    public void run() {
        for (int i = 0; i < Obstacle.NUM_MOVES; i++) {
            synchronized (board) {
                Cell currentCell = board.getCell(obstacle.getPosition());
                List<BoardPosition> possibleMoves = board.getNeighboringPositions(currentCell);

                // Filtra posi��es ocupadas e escolhe uma aleatoriamente
                possibleMoves.removeIf(pos -> board.getCell(pos).isOcupied());
                if (!possibleMoves.isEmpty()) {
                    BoardPosition newPosition = possibleMoves.get(random.nextInt(possibleMoves.size()));
                    Cell newCell = board.getCell(newPosition);

                    // Move o obst�culo para a nova posi��o
                    currentCell.setGameElement(null);
                    newCell.setGameElement(obstacle);
                    obstacle.setPosition(newPosition);

                    // Notifica os observadores sobre a mudan�a
                    board.setChanged();
                    board.notifyObservers();
                }
            }

            // Aguarda um intervalo antes de tentar mover novamente
            try {
                Thread.sleep(Obstacle.OBSTACLE_MOVE_INTERVAL);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }
}
