package game;

import java.io.Serializable;
import java.util.LinkedList;

import environment.LocalBoard;
import gui.SnakeGui;
import environment.Board;
import environment.BoardPosition;
import environment.Cell;
/** Base class for representing Snakes.
 * Will be extended by HumanSnake and AutomaticSnake.
 * Common methods will be defined here.
 * @author luismota
 *
 */
public abstract class Snake extends Thread implements Serializable{
	private static final int DELTA_SIZE = 10;
	protected LinkedList<Cell> cells = new LinkedList<Cell>();
	protected int size = 5;
	private int id;
	public Board board;
	
	public Snake(int id,Board board) {
		this.id = id;
		if (board == null) {
            throw new IllegalArgumentException("O board passado para Snake � null");
        }
		this.board=board;
	}

	public int getSize() {
		return size;
	}

	public int getIdentification() {
		return id;
	}

	public int getLength() {
		return cells.size();
	}
	
	public LinkedList<Cell> getCells() {
		return cells;
	}
	
	protected synchronized void move(Cell newCell) throws InterruptedException {
	    //System.out.println("Cobra " + getIdentification() + " tentando se mover para " + newCell.getPosition());
	    try {
	        // Verifique se a nova c�lula est� ocupada por um pr�mio.
	        if (newCell.getGameElement() instanceof Goal) {
	            Goal goal = (Goal) newCell.getGameElement();
	            // Aumente o tamanho da cobra pelo valor do pr�mio.
	            size += goal.getValue();
	            // Remova o pr�mio do tabuleiro.
	            newCell.setGameElement(null);
	        }

	        // Adicione a nova c�lula � cabe�a da cobra.
	        cells.addFirst(newCell);

	        // Se a cobra n�o cresceu, remova a c�lula da cauda.
	        if (cells.size() > size) {
	            Cell tail = cells.removeLast();
	            // Libere a c�lula da cauda.
	            tail.release();
	        }

	        // Solicite a nova c�lula para a cobra.
	        newCell.request(this);

	        // Notifique o tabuleiro sobre a mudan�a para atualizar a GUI.
	        board.setChanged();
	        board.notifyObservers();

	        //System.out.println("Cobra " + getIdentification() + " moveu-se para " + newCell.getPosition());
	    } catch (Exception e) {
	        System.out.println("Exce��o capturada na cobra " + getIdentification() + ": " + e.getMessage());
	        e.printStackTrace();
	        throw e; // Re-lan�a a exce��o para que ela n�o seja silenciosamente ignorada.
	    }
	}


	public LinkedList<BoardPosition> getPath() {
		LinkedList<BoardPosition> coordinates = new LinkedList<BoardPosition>();
		for (Cell cell : cells) {
			coordinates.add(cell.getPosition());
		}

		return coordinates;
	}	
	protected void doInitialPositioning() {
		// Random position on the first column. 
		// At startup, snake occupies a single cell
		int posX = 0;
		int posY = (int) (Math.random() * Board.NUM_ROWS);
		BoardPosition at = new BoardPosition(posX, posY);
		
		try {
			board.getCell(at).request(this);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		cells.add(board.getCell(at));
		System.err.println("Snake "+getIdentification()+" starting at:"+getCells().getLast());		
	}
	
	public Board getBoard() {
		return board;
	}
	
	
}
