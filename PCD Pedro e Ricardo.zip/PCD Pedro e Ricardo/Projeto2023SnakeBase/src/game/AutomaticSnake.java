package game;

import java.util.List;
import java.util.Random;
import environment.Board;
import environment.BoardPosition;
import environment.Cell;

public class AutomaticSnake extends Snake {
    private Random random = new Random();

    public AutomaticSnake(int id, Board board) {
        super(id, board);
        // A verifica��o de null para o board j� � feita no construtor da superclasse.
    }

    @Override
    public void run() {
        doInitialPositioning();
        System.err.println("Cobra " + getIdentification() + " inicializada com tamanho: " + cells.size());
        try {
            while (!interrupted()) {
                Cell currentCell = cells.getFirst();
                List<BoardPosition> possibleMoves = board.getNeighboringPositions(currentCell);
                BoardPosition nextPosition = chooseRandomPosition(possibleMoves);

                // Imprime as posi��es vizinhas poss�veis
                //System.out.println("Cobra " + getIdentification() + " posi��es vizinhas: " + possibleMoves);

                if (nextPosition != null) {
                    move(board.getCell(nextPosition));
                    //System.out.println("Cobra " + getIdentification() + " moveu para " + nextPosition);
                } else {
                   // System.out.println("Cobra " + getIdentification() + " n�o encontrou movimentos poss�veis.");
                }

                Thread.sleep(500); // Pausa entre movimentos para tornar a movimenta��o vis�vel.
            }
        } catch (InterruptedException e) {
            System.out.println("Cobra " + getIdentification() + " interrompida.");
            e.printStackTrace();
        }
    }


    private BoardPosition chooseRandomPosition(List<BoardPosition> possibleMoves) {
        while (!possibleMoves.isEmpty()) {
            int index = random.nextInt(possibleMoves.size());
            BoardPosition position = possibleMoves.remove(index);
            Cell cell = board.getCell(position);
            if (!cell.isOcupied()) {
                return position;
            }
        }
        return null; // N�o h� movimentos poss�veis.
    }
    
    @Override
    protected void move(Cell newCell) throws InterruptedException {
            synchronized (board) {
            try {
                // Verifique se a nova c�lula est� ocupada por um pr�mio.
                if (newCell.getGameElement() instanceof Goal) {
                    Goal goal = (Goal) newCell.getGameElement();
                    size += goal.getValue();
                    newCell.setGameElement(null);
                    cells.addFirst(newCell);
                } else {
                    cells.addFirst(newCell);
                    if (cells.size() > size) {
                        Cell tail = cells.removeLast();
                        tail.release();
                    }
                }
                newCell.request(this);
                board.setChanged();
                board.notifyObservers();
                //System.out.println("Cobra " + getIdentification() + " moveu-se para " + newCell.getPosition());
            } catch (Exception e) {
                System.out.println("Exce��o capturada na cobra " + getIdentification() + ": " + e.getMessage());
                e.printStackTrace();
                // N�o re-lance a exce��o para evitar parar a thread abruptamente.
                // Em vez disso, registre a exce��o e talvez defina um estado de erro.
            }
        }
    }
    
    public Board getBoard(){
        return board;
    }
}
