package environment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Observable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Collections;
import game.ObstacleMover;
import game.GameElement;
import game.Goal;
import game.Obstacle;
import game.Server;
import game.Snake;
import game.AutomaticSnake;

/** Class representing the state of a game running locally
 * 
 * @author luismota
 *
 */
public class LocalBoard extends Board{
	
	public static final int NUM_SNAKES = 2;
	public static final int NUM_OBSTACLES = 25;
	public static final int NUM_SIMULTANEOUS_MOVING_OBSTACLES = 3;
	private ObstacleMover obstaclemover;
	

	public LocalBoard() {
		super();
		if (this == null) {
            throw new IllegalStateException("This n�o pode ser null");
		}
		System.out.println(snakes);

		addObstacles( NUM_OBSTACLES);
		
		Goal goal=addGoal();
//		System.err.println("All elements placed");
		
	}

	public void init() {
		 initSnakes(); // Inicializa as cobras
		    for (Snake snake : snakes) {
		        snake.start(); // Inicia a thread de cada cobra
		    }
		    moveObstacles(); // Inicia o movimento dos obst�culos
		    setChanged();
		    notifyObservers(); // Notifica a GUI para redesenhar o tabuleiro
		}
	
	    // M�todo para iniciar o movimento dos obst�culos.
	    public void moveObstacles() {
	        // Crie um pool de threads para mover os obst�culos.
	        ExecutorService executor = Executors.newFixedThreadPool(NUM_SIMULTANEOUS_MOVING_OBSTACLES);

	        // Escolha aleatoriamente tr�s obst�culos para mover.
	        Collections.shuffle(obstacles);
	        List<Obstacle> selectedObstacles = obstacles.subList(0, NUM_SIMULTANEOUS_MOVING_OBSTACLES);

	        // Inicie um ObstacleMover para cada obst�culo selecionado.
	        for (Obstacle obstacle : selectedObstacles) {
	            ObstacleMover mover = new ObstacleMover(obstacle, this);
	            executor.execute(mover);
	        }

	        // Desligue o executor ap�s iniciar os movers.
	        executor.shutdown();
	    }
	

	public ObstacleMover getObstacleMover(){
		return obstaclemover;
	}
	
	private void initSnakes() {
	    for (int i = 0; i < NUM_SNAKES; i++) {
	        AutomaticSnake snake = new AutomaticSnake(i, this);
	        snakes.add(snake);
	    }
    }


	

	@Override
	public void handleKeyPress(int keyCode) {
		// do nothing... No keys relevant in local game
	}

	@Override
	public void handleKeyRelease() {
		// do nothing... No keys relevant in local game
	}

}
