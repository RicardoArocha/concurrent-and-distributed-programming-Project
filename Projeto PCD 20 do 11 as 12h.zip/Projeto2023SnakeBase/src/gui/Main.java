package gui;

import environment.LocalBoard;

public class Main {
	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) {
		LocalBoard board=new LocalBoard();
		SnakeGui game = new SnakeGui(board,1000,200); //Posicao no tabuleiro em H,V. Valores originais 600, 200
		game.init();
		// Launch server
		// TODO
		
	}
}

/*
 * COISAS A EMPLEMENTAR
 * j
 * Movimento inteligente // FEITO
 *
 * Botao para ativar movimento inteligente // FEITO
 * 
 * ThreadPool de obstaculos 
 * 
 * Interrupcao de todos os threads e Msg a dizer quem ganhou
 * 
 * 
 * PROBLEMAS ENCONTRADOS E QUE ESTAO POR RESOLVER
 * 
 * 
 * 
 * 
 * 
 */