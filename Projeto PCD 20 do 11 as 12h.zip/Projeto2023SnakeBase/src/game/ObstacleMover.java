package game;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import environment.LocalBoard;

public class ObstacleMover extends Thread {
	private Obstacle obstacle;
	private LocalBoard board;
	
	public ObstacleMover(Obstacle obstacle, LocalBoard board) {
		super();
		this.obstacle = obstacle;
		this.board = board;
	}

//	@Override //Original
//	public void run() {
//		// TODO
//	}
	
	@Override
	public void run() {
		// TODO
		
//		try {   Versao de 19/11/23
//			while (!interrupted()) {
//				
//			LinkedList<Obstacle> obstacles = board.getObstacles();
//			
//			Collections.shuffle(obstacles);
//			
//			List<Obstacle> selectedObstacles = obstacles.subList(0, Math.min(3, obstacles.size()));
//			
//			for(Obstacle obs : selectedObstacles) {
//				obs.move();
//			}			
//				
//			Thread.sleep(obstacle.OBSTACLE_MOVE_INTERVAL);
//			}			
//		} catch (Exception e) {
//            e.printStackTrace();
//		}
		
		
		//Versao corrigida para mover sempre o maximo de obstaculos, ou seja 3
		//A versao acima podia tentar mover objetos imoviveis, fazendo com que nem sempre 3 se movessem
		//Versao de 20/11/23
		LinkedList<Obstacle> obstacles = board.getObstacles();
		
		LinkedList<Obstacle> obstaclesToRemove = new LinkedList<Obstacle>();
		
		try {
			while (!interrupted()) {				
			
			if(obstacles.isEmpty()) break;
				
			Collections.shuffle(obstacles);
			
			List<Obstacle> selectedObstacles = obstacles.subList(0, Math.min(3, obstacles.size()));
			
			
			for(Obstacle obs : selectedObstacles) {
				if(!obs.move()) obstaclesToRemove.add(obs);
				
			}		
			
			for(Obstacle obs : obstaclesToRemove) {
				if(!obs.move()) obstacles.remove(obs);				
			}		
			
				
			Thread.sleep(obstacle.OBSTACLE_MOVE_INTERVAL);
			}			
		} catch (Exception e) {
            e.printStackTrace();
		}
		
		
		
	}
	
}
