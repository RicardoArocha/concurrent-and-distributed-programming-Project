package game;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;
import environment.LocalBoard;


/*
 * TODO
 * As cobras devem tentar andar contra obstaculos e ficar em estado de espera
 * 
 * Deve haver um botao que retire a cobra desse estado de espera, mesmo que o obstaculo nao tenha sido movido, para ela poder escolher um caminho alternativo
 * 
 * falta fazer o move na propria cobra
 * 
 * falta fazer o smartMove, e fazer o botao funcionar e a cobra de facto ficar a escutar
 * 
 * */


public class AutomaticSnake extends Snake {
	public AutomaticSnake(int id, LocalBoard board) {
		super(id,board);

	}
	
	private boolean hasDoneInitialPositioning = false;
	private int doXAmountOfSmartMovements = 0;	

	@Override
	public void run() {
		if(!hasDoneInitialPositioning) {
			doInitialPositioning();
			hasDoneInitialPositioning = true;
		}		
		//System.err.println("initial size:"+cells.size()); //Original, para referencia futura
//		try {
//			cells.getLast().request(this);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		//TODO: automatic movement
		
		
		try {
            while (!interrupted()) {
            	
        	//Posso vir a implementar smartMove e dumbMove
        	
        	//Cria lista com possiveis movimentos, dumbPossibleMoves ou smartPossibleMoves consuante a variavel doXAmountOfSmartMovements,
            //escolhe o melhor movimento, bestMove, e tenta mover a cobra para la, move se nao for null.
            if(doXAmountOfSmartMovements > 0) {
            	if(bestMove(smartPossibleMoves()) != null) move(board.getCell(bestMove(smartPossibleMoves())));
            	doXAmountOfSmartMovements --;
            }
            else {
            	if(bestMove(dumbPossibleMoves()) != null) move(board.getCell(bestMove(dumbPossibleMoves()))); 
            }
            
            Thread.sleep(board.PLAYER_PLAY_INTERVAL);	          	
            	
                 
                
            }
        } catch (InterruptedException e) {
            System.out.println("Cobra " + getIdentification() + " interrompida.");
            e.printStackTrace();
            //doXAmountOfSmartMovements ++; //A cobra acumula movimentos inteligentes e nunca fica presa durante os mesmos
            doXAmountOfSmartMovements = 1; //A cobra tem que ser manuamente desbloqueada
            run();
        }	
		
	}
	
	//Feito
	
	public List<BoardPosition> dumbPossibleMoves() { //Escolhe o melhor movimento para chegar ao obstaculo, mas ignora objetos e outras cobras
		 Cell snakeHead=cells.getFirst();	//Cabeca da cobra, pela qual vao ser calculados todos os movimentos
		 
		 ArrayList<BoardPosition> possibleMoves = new ArrayList<BoardPosition>(); //Lista de resultados a ser devolvida
		 List<BoardPosition> neighboringCells = board.getNeighboringPositions(snakeHead); //Lista de todas as Cell vizinhas
		
		for(BoardPosition testedMove : neighboringCells) {
			Cell testedCell = board.getCell(testedMove);
			
			//Verifica se a cell esta ocupada por uma snake, e se sim, verifica se essa snake e ela mesma. Se for da skip
			//Ou seja, so nao se vai tentar mover para ela mesma
			if(testedCell.isOcupiedBySnake())if(testedCell.getOcuppyingSnake().getIdentification() == getIdentification()) continue;
			
			possibleMoves.add(testedMove);			
		}
		
		return possibleMoves; 
	};
	
	//Acabar de desenvolver, mas fazer primeiro dumbPossibleMoves !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	
	public List<BoardPosition> smartPossibleMoves() { //Escolhe o melhor movimento para chegar ao obstaculo, tem em consideracao objetos e outras cobras
		 Cell snakeHead=cells.getFirst();	//Cabeca da cobra, pela qual vao ser calculados todos os movimentos
		 
		 ArrayList<BoardPosition> possibleMoves = new ArrayList<BoardPosition>(); //Lista de resultados
		 List<BoardPosition> neighboringCells = board.getNeighboringPositions(snakeHead);//Lista a ser iterada
		
		 for(BoardPosition testedMove : neighboringCells) {
				Cell testedCell = board.getCell(testedMove);
				
				//Verifica se a cell esta ocupada por uma snake, e se sim, verifica se essa snake e ela mesma. Se for da skip
				//Ou seja, so nao se vai tentar mover para ela mesma
				if(testedCell.getGameElement() != null)if(!(testedCell.getGameElement() instanceof Goal))  continue;
				
				possibleMoves.add(testedMove);			
			}
		
		return possibleMoves; 
	}
	
	
	//Feito
	
	public BoardPosition bestMove(List<BoardPosition> possibleMoves) { //Compara distancias ao goal e da o que estiver mais perto
		if(possibleMoves.isEmpty()) return null; 
		
		Collections.shuffle(possibleMoves); //Desta forma nao sao priotizadas certas direcoes
		
		BoardPosition goalPosition = board.getGoalPosition();
		
		BoardPosition bestMove = possibleMoves.get(0); 
		
		for(BoardPosition testedPosition : possibleMoves) {
			if(goalPosition.distanceTo(testedPosition) < goalPosition.distanceTo(bestMove)) bestMove = testedPosition;
		}
		
		return bestMove;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
