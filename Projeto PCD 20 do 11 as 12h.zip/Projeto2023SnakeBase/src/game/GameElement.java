package game;

/*
 *
 * 
 * */
public abstract class GameElement extends Thread{ //public abstract class GameElement

}
