package ex1.multithread;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class TestClient2 {

	public static void main(String[] args) throws UnknownHostException {
		Client clientApp2 = new Client(InetAddress.getByName("localhost"), 12345);
		clientApp2.runClient();

	}

}
