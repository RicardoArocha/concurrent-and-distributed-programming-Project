package ex1.multithread;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
	private ServerSocket server;
	
	
	private void runServer() {
		try {
			// 1. Create socket
			server = new ServerSocket(12345, 50);
			while(true) {
				// 2. Wait for a new connection
				waitForConnection();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}

	private void waitForConnection() throws IOException {
		System.out.println("Waiting for a new connection...");
		Socket connection = server.accept(); // WAIT!!
		
		// Create a connection manager (ConnectionHandler)
		ConnectionHandler handler = new ConnectionHandler(connection);
		handler.start();
		System.out.println("[new connection] " + connection.getInetAddress().getHostName());
	}

	private class ConnectionHandler extends Thread {
		private Socket connection;
		private Scanner in;
		private PrintWriter out;
		
		public ConnectionHandler(Socket connection) {
			this.connection = connection;
		}

		@Override
		public void run() {
			try {
				getStreams();
				processConnection();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				closeConnection();
			}
		}
		
		
		private void getStreams() throws IOException {
			// Writer
			out = new PrintWriter(connection.getOutputStream(), true);
			// Reader
			in = new Scanner(connection.getInputStream());
			System.out.println("[ready to proceed connection]");
		}

		private void processConnection() {
			String msg;
			do {
				// Read message
				msg = in.nextLine(); // WAIT!!
				System.out.println("[received] " + msg);
				// Write echo
				out.println("[server echo] " + msg);			
				
			}while(!"END".equals(msg));
			
		}

		private void closeConnection() {
			try {
				if(in != null)
					in.close();
				if(out != null)
					out.close();
				if(connection != null)
					connection.close();
			} catch (IOException e) {
				e.printStackTrace();
			}		
		}
		
		
		
		
		
		
	}
	
	
	
	
	public static void main(String[] args) {
		Server serverApp = new Server();
		serverApp.runServer();

	}


}
