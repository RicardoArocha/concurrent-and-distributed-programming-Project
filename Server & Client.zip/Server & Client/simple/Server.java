package ex1.simple;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
	private ServerSocket server;
	private Socket connection;
	private Scanner in;
	private PrintWriter out;
	
	private void runServer() {
		try {
			// 1. Create socket
			server = new ServerSocket(12345, 1);
			// 2. Wait for a new connection
			waitForConnection();
			// 3. Create i/o streams - to communicate
			getStreams();
			// 4. Process connection
			processConnection();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// 5. Closer connection
			closeConnection();
		}
		
		
	}

	private void waitForConnection() throws IOException {
		System.out.println("Waiting for a new connection...");
		connection = server.accept(); // WAIT!!
		
		System.out.println("[new connection] " + connection.getInetAddress().getHostName());
	}

	private void getStreams() throws IOException {
		// Writer
		out = new PrintWriter(connection.getOutputStream(), true);
		// Reader
		in = new Scanner(connection.getInputStream());
		System.out.println("[ready to proceed connection]");
	}

	private void processConnection() {
		String msg;
		do {
			// Read message
			msg = in.nextLine(); // WAIT!!
			System.out.println("[received] " + msg);
			// Write echo
			out.println("[server echo] " + msg);			
			
		}while(!"END".equals(msg));
		
	}

	private void closeConnection() {
		try {
			if(in != null)
				in.close();
			if(out != null)
				out.close();
			if(connection != null)
				connection.close();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}

	public static void main(String[] args) {
		Server serverApp = new Server();
		serverApp.runServer();

	}


}
