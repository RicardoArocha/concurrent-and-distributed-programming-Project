package remote;


/** Remore client, only for part II
 * 
 * @author luismota
 *
 */

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

import environment.Board;
import environment.Cell;
import environment.LocalBoard;
import gui.SnakeGui;

public class Client { //Default was empty
	private Socket connection;
	//private Scanner in; //Nao vou usar, pois quero receber objetos
	private ObjectInputStream objectInput; //representa as boardCells que vou receber para poder atualizar o RemoteBoard
	private PrintWriter out;
	
	private InetAddress serverAddress;
	private int port;
	
	//Clients Own RemoteBoard	
	private RemoteBoard remoteBoard;

	public Client(InetAddress serverAddress, int port) {
		this.serverAddress = serverAddress;
		this.port = port;
		
		remoteBoard = newRemoteBoard();
	}

	public void runClient() {
		try {
			// 1. Connect to server
			connection = new Socket(serverAddress, port);
			// 2. Get streams
			getStreams();
			// 3. Process connection
			processConnection();
		} catch (IOException e) {
			// TODO: handle exception
		} finally {
			// 4. Close connection
			closeConnection();
		}
	}

	private void getStreams() throws IOException {
		// Writer
		out = new PrintWriter(connection.getOutputStream(), true);
		// Reader
		//in = new Scanner(connection.getInputStream()); //Nao vou usar
		objectInput = new ObjectInputStream(connection.getInputStream());
		
		System.out.println("[ready to proceed connection]");
	}

//	private void processConnection() {
//		String msg = "Hello ";
//		for(int i = 0; i < 5; i++) {
//			// Write message
//			out.println(msg + i);
//			System.out.println("[sent message] " + msg + i);
//			// Receive eco (read message)
//			//System.out.println(in.nextLine()); // WAIT!! //Nao vou usar
//			
//			try {
//				Thread.sleep(3000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		out.println("END");
//	}
	
	private void processConnection() { //Deve receber em objeto as cells atualizadas da board  //POR FAZER
		Object in;
		do {
			
			try {
				
				in = objectInput.readObject();
				
				if(in instanceof Cell[][]) remoteBoard.updateRemoteBoard((Cell[][])in);
				
				
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			
		}while(true); //Alterar mais tarde para algo diferente de true
		
	}

	private void closeConnection() {
		try {
//			if(in != null)
//				in.close();
			if (objectInput != null) {
		        objectInput.close();
		    }
			if(out != null)
				out.close();
			if(connection != null)
				connection.close();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	//Start of Added Functions
	
	private RemoteBoard newRemoteBoard() {
		RemoteBoard board=new RemoteBoard(this);	
		return board;
	}
	
	public void sendMessageToServer(String message) { //Envia o movimento desejado ao servidor
		out.println(message);
	}
	
	
	//End of Added Functions
	

	public static void main(String[] args) throws UnknownHostException {
		Client clientApp = new Client(InetAddress.getByName("localhost"), 12345);
		clientApp.runClient();
	}

}
