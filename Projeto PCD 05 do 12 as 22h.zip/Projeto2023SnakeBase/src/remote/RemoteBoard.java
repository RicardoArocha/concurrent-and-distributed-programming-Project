package remote;

import java.awt.event.KeyEvent;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;
import gui.SnakeGui;

/** Remote representation of the game, no local threads involved.
 * Game state will be changed when updated info is received from Srver.
 * Only for part II of the project.
 * @author luismota
 *
 */

public class RemoteBoard extends Board{
	
	private Client client;

	public RemoteBoard(Client client) {
		super();
		this.client = client;
		
		startSnakeGUI();
	}
	
	private void startSnakeGUI() {
		SnakeGui game = new SnakeGui(this,400,200); //Posicao no tabuleiro em H,V
		game.init();
	}
	
	@Override
	public void handleKeyPress(int keyCode) {
		//TODO
		String message = null;
		
		switch (keyCode) {
        case KeyEvent.VK_UP:
            message = "UP";
            break;
        case KeyEvent.VK_DOWN:
            message = "DOWN";
            break;
        case KeyEvent.VK_LEFT:
            message = "LEFT";
            break;
        case KeyEvent.VK_RIGHT:
            message = "RIGHT";
            break;
    }		
		if(message != null) client.sendMessageToServer(message);
	}
	

	@Override
	public void handleKeyRelease() { //nao vejo necessidade de implementar
		// TODO
	}

	@Override
	public void init() { // nao vejo necessidade de implementar
	}

	public void updateRemoteBoard(Cell[][] newCells) { //Atualiza a remote board com todas as novas celulas
		for (int x = 0; x < NUM_COLUMNS; x++) {
			for (int y = 0; y < NUM_ROWS; y++) {
				cells[x][y] = newCells[x][y];
			}
		}
		setChanged();
	}
	

}
