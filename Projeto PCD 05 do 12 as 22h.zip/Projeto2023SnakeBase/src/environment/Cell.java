package environment;

import java.io.Serializable;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import game.GameElement;
import game.Goal;
import game.Obstacle;
import game.Snake;
/** Main class for game representation. 
 * 
 * @author luismota
 *
 */
/*
 /*
  * E importante usarmos locks nesta classe para impedirmos que uma cell possa ser ocupada por diferentes tipos de objetos, impedir acesso a mesma cell por diferente
  * 
  * */
/*
 *  
 * 
 * */
public class Cell implements Serializable{
	private BoardPosition position;
	private Snake occupyingSnake = null;
	private GameElement gameElement=null; 
	
	private transient final Lock l = new ReentrantLock(); //transient faz com que seja ignorado ao ser serialized
	private transient final Condition cellOccupied = l.newCondition();
	
	public GameElement getGameElement() {
		return gameElement;
	}


	public Cell(BoardPosition position) {
		super();
		this.position = position;
	}

	public BoardPosition getPosition() {
		return position;
	}

	public int request(Snake snake) throws InterruptedException { //public void request(Snake snake)
		//TODO coordination and mutual exclusion
		//TODO agir caso seja um Goal. Done
		int goalValue = 0;
		l.lock();
		try {
			while(gameElement instanceof Snake || gameElement instanceof Obstacle) {
				cellOccupied.await();
			}
			if(isOcupiedByGoal()) {
				goalValue = removeGoal().captureGoal();
			}
			occupyingSnake=snake;
			setGameElement(snake);
		}finally{
			l.unlock();
		}		
		return goalValue;
	}

	public void release() { //Liberta a Cell
		//TODO	
		l.lock();
		try {
			occupyingSnake = null;
			gameElement = null;
			
			cellOccupied.signalAll();
		}finally {
			l.unlock();
		}
		
	}

	public boolean isOcupiedBySnake() {
		return occupyingSnake!=null;
	}


	public void setGameElement(GameElement element) { //Altera o gameElement, a ser utilizado pelas outras funcoes
		// TODO coordination and mutual exclusion
		l.lock();
		try {
			//adicionar verificacao
			gameElement=element;
		} finally {
			l.unlock();
		}
		

	}

	public boolean isOcupied() { //Isto deve ser usado por cobras, visto que nao faz mencao de Goal
		return isOcupiedBySnake() || (gameElement!=null && gameElement instanceof Obstacle);
		//return !(gameElement==null || gameElement instanceof Goal);
	}


	public Snake getOcuppyingSnake() {
		return occupyingSnake;
	}


	public  Goal removeGoal() throws InterruptedException { //Remove o Goal e devolve o Goal removido
		// TODO
		if(!(gameElement instanceof Goal))return null;
		
		l.lock();	
		
		Goal removedGoal = (Goal)gameElement;
		try {
			setGameElement(null);
			cellOccupied.signalAll();
		} finally {
			l.unlock();
		}
		
		return removedGoal;
	}
	public void removeObstacle() throws InterruptedException { //Remove o Obstaculo
	//TODO
		if(!(gameElement instanceof Obstacle)) return; //Garante que a cell e um obstaculo
		
		l.lock();
		try {
			setGameElement(null);
			cellOccupied.signalAll();
		} finally {
			l.unlock();
		}
		
	}


	public Goal getGoal() {
		return (Goal)gameElement;
	}


	public boolean isOcupiedByGoal() {
		return (gameElement!=null && gameElement instanceof Goal);
	}
	
	

}
