package game;

import java.io.Serializable;

/*
 *
 * 
 * */
public abstract class GameElement extends Thread implements Serializable{ //public abstract class GameElement

}
