package game;

import java.io.Serializable;
import java.util.LinkedList;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;
/** Base class for representing Snakes.
 * Will be extended by HumanSnake and AutomaticSnake.
 * Common methods will be defined here.
 * @author luismota
 *
 */
/*
 * OUTRAS IDEIAS
 * 
 *Ver como esta implementado o crescimento no Ricardo e adaptar
 * 
 * Adicionar variavel para acrescentar cauda a cobra, esta variavel impede o tail.release()
 * */
public class Snake extends GameElement implements Serializable{ //public abstract class Snake extends Thread implements Serializable //Retirei o abstract para poder criar instancias de Snake no Server
	private static final int DELTA_SIZE = 10;
	protected LinkedList<Cell> cells = new LinkedList<Cell>();
	protected int size = 5;
	int sizeToAdd = 0;
	private int id;
	protected Board board;
	
	protected volatile boolean shutDownRequested = false; //Necessario para distinguir o reset do movement e o shutdown quando a thread for interrompida
	
	public Snake(int id,Board board) {
		this.id = id;
		this.board=board;
	}

	public int getSize() {
		return size;
	}

	public int getIdentification() {
		return id;
	}

	public int getLength() {
		return cells.size();
	}
	
	public LinkedList<Cell> getCells() {
		return cells;
	}
	protected void move(Cell cell) throws InterruptedException {
		
		sizeToAdd = 0; //Necessario para garantir que o jogo termina apos a cobra comer o objetivo e esta mudanca ser visivel
		
		// A verificacao da cell e toda feita pelo cell.request, nao sendo preciso haver casos ou verificacoes nesta classe
		sizeToAdd = cell.request(this); //Caso o goal seja capturado, aumenta o size
		
		size += sizeToAdd;
		
		cells.addFirst(cell); 
		if(cells.size() > size) { //Caso a cobra precise de crescer, nao remove a ultima posicao
			Cell tail = cells.removeLast();
			tail.release();
		}
		
		board.setChanged(); //Altera a board, atualizando as imagens
		
		if(sizeToAdd == 9) board.shutDown(); //Caso o ultimo goal tenha sido comido, pede a board que termine todos os threads
		
	}
	
	public void move(String direction) throws InterruptedException { //Move a cobra na direcao pedida somente se a nova cell estiver livre
		BoardPosition head = getPath().getFirst();
		Cell newCell;
		
		switch (direction) {
	    case "LEFT":
	    	if(head.x==0) return;
	    	
	    	newCell = board.getCell(head.getCellLeft());
	    	if(!newCell.isOcupied()) move(newCell);	    	
	    	
	        break;
	        
	    case "RIGHT":
	    	if(head.x==board.NUM_COLUMNS-1) return;
	    	
	    	newCell = board.getCell(head.getCellRight());
	    	if(!newCell.isOcupied()) move(newCell);
	    	
	        break;
	        
	    case "UP":
	    	if(head.y==0) return;
	    	
	    	newCell = board.getCell(head.getCellAbove());
	    	if(!newCell.isOcupied()) move(newCell);
	    	
	        break;
	        
	    case "DOWN":
	    	if(head.y==board.NUM_ROWS-1) return;
	    	
	    	newCell = board.getCell(head.getCellBelow());
	    	if(!newCell.isOcupied()) move(newCell);
	    		    	
	        break;
	        
//	    default: // Nao e preciso, existe return no fim anyway
//	        return;
		}			
		return;
	}
	
	public LinkedList<BoardPosition> getPath() {
		LinkedList<BoardPosition> coordinates = new LinkedList<BoardPosition>();
		for (Cell cell : cells) {
			coordinates.add(cell.getPosition());
		}

		return coordinates;
	}	
	protected void doInitialPositioning() {
		// Random position on the first column. 
		// At startup, snake occupies a single cell
		int posX = 0;
		int posY = (int) (Math.random() * Board.NUM_ROWS);
		BoardPosition at = new BoardPosition(posX, posY);
		
		try {
			board.getCell(at).request(this);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		cells.add(board.getCell(at));
		System.err.println("Snake "+getIdentification()+" starting at:"+getCells().getLast());		
	}
	
	public Board getBoard() {
		return board;
	}
	
	public void requestShutdown() {
		shutDownRequested = true;
		this.interrupt();
	}
	
	
}
